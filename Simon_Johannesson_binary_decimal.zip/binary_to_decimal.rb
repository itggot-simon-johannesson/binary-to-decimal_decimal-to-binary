def binary_to_decimal()
    binary = ARGV[0]
    decimal = ""

    binary.each do |i|
      tio = 2 ** i
      decimal = decimal + tio
    end
end

binary_to_decimal()

# def binary_to_decimal()
#   binary = ARGV[0]
#   decimal = ""
#
#   binary.each do |i|
#     j = 2 ** i.to_i
#     decimal = decimal + j
#   end
#
# puts decimal
#
# end
#
# binary_to_decimal()
